var searchData=
[
  ['rezultatų_20skaičiavimo_20sistema_20v0_201_0',['Studentų Rezultatų Skaičiavimo Sistema (v0.1)',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html',1,'']]],
  ['rezultatų_20skaičiavimo_20sistema_20v1_200_1',['Studentų Rezultatų Skaičiavimo Sistema (v1.0)',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md14',1,'']]],
  ['rezultatai_2',['Rezultatai',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md17',1,'']]]
];
