var searchData=
[
  ['1_0',['Studentų Rezultatų Skaičiavimo Sistema (v0.1)',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html',1,'']]]
];
