var searchData=
[
  ['failų_20struktūra_0',['Failų Struktūra',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['failų_20struktūra_1',['Failų struktūra',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md16',1,'']]],
  ['funkcijos_3a_2',['Naujos funkcijos:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['funkcionalumas_3',['Funkcionalumas',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
