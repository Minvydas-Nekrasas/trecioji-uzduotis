var searchData=
[
  ['laikų_20palyginimas_0',['100 000 Įrašų Laikų Palyginimas',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md34',1,'']]],
  ['laiko_20palyginimas_3a_1',['Optimizavimo strategijų (O1, O2, O3) laiko palyginimas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md31',1,'']]],
  ['laiko_20spartos_20matavimai_2',['Vidutiniai laiko spartos matavimai',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md18',1,'']]],
  ['laiko_20spartos_20matavimai_20list_3',['Vidutiniai laiko spartos matavimai (list)',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md12',1,'']]],
  ['laiko_20spartos_20matavimai_20vector_4',['Vidutiniai laiko spartos matavimai (vector)',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['list_5',['Vidutiniai laiko spartos matavimai (list)',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md12',1,'']]],
  ['listais_20tt_20struct_20tt_20ir_20tt_20class_20tt_20palyginimas_3a_6',['3 strategija su listais &lt;tt&gt;struct&lt;/tt&gt; ir &lt;tt&gt;class&lt;/tt&gt; palyginimas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md26',1,'']]]
];
