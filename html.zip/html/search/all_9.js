var searchData=
[
  ['detalus_20aprašymas_3a_0',['Detalus aprašymas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md38',1,'']]]
];
