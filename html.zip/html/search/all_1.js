var searchData=
[
  ['1_0',['1',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html',1,'Studentų Rezultatų Skaičiavimo Sistema (v0.1)'],['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md24',1,'v1.1']]],
  ['1_20000_20000_1',['1 000 000',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md22',1,'']]],
  ['1_20000_20000_3a_2',['1 000 000:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md28',1,'1 000 000:'],['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md33',1,'1 000 000:']]],
  ['10_20000_3',['10 000',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md20',1,'']]],
  ['10_20000_20000_4',['10 000 000',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md23',1,'']]],
  ['10_20000_20000_3a_5',['10 000 000:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md27',1,'10 000 000:'],['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md32',1,'10 000 000:']]],
  ['100_20000_6',['100 000',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md21',1,'']]],
  ['100_20000_20įrašų_20laikų_20palyginimas_7',['100 000 Įrašų Laikų Palyginimas',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md34',1,'']]],
  ['100_20000_3a_8',['100 000:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md29',1,'']]],
  ['1000_9',['1000',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md19',1,'']]]
];
