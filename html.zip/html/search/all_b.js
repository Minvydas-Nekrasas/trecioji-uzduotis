var searchData=
[
  ['h_3a_0',['Sukurta bazinė klasė žmogus. zmogus.h:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md43',1,'']]]
];
