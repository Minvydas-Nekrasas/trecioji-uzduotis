var indexSectionsWithContent =
{
  0: "01235:abcdfhiklmnoprstvzįž",
  1: "sz",
  2: "1rsv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "Visi",
  1: "Klasės",
  2: "Puslapiai"
};

