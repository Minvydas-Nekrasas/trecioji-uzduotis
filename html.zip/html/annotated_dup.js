var annotated_dup =
[
    [ "Studentas", "class_studentas.html", null ],
    [ "Zmogus", "class_zmogus.html", null ]
];