var searchData=
[
  ['matavimai_0',['Vidutiniai laiko spartos matavimai',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md18',1,'']]],
  ['matavimai_20list_1',['Vidutiniai laiko spartos matavimai (list)',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md12',1,'']]],
  ['matavimai_20vector_2',['Vidutiniai laiko spartos matavimai (vector)',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
