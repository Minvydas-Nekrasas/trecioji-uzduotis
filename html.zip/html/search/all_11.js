var searchData=
[
  ['o1_20o2_20o3_20laiko_20palyginimas_3a_0',['Optimizavimo strategijų (O1, O2, O3) laiko palyginimas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md31',1,'']]],
  ['o2_20o3_20laiko_20palyginimas_3a_1',['Optimizavimo strategijų (O1, O2, O3) laiko palyginimas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md31',1,'']]],
  ['o3_20laiko_20palyginimas_3a_2',['Optimizavimo strategijų (O1, O2, O3) laiko palyginimas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md31',1,'']]],
  ['operatorius_20strong_20_3a_3',['Parašytas &lt;strong&gt;&quot;&gt;&gt;&quot; ir &quot;&lt;&lt;&quot; operatorius&lt;/strong&gt;:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md39',1,'']]],
  ['optimizavimo_20strategijų_20o1_20o2_20o3_20laiko_20palyginimas_3a_4',['Optimizavimo strategijų (O1, O2, O3) laiko palyginimas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md31',1,'']]]
];
