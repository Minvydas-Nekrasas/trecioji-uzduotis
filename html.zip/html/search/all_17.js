var searchData=
[
  ['zmogus_0',['Zmogus',['../class_zmogus.html',1,'']]],
  ['zmogus_20cpp_3a_1',['zmogus.cpp:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md44',1,'']]],
  ['zmogus_20h_3a_2',['Sukurta bazinė klasė žmogus. zmogus.h:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md43',1,'']]]
];
