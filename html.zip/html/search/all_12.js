var searchData=
[
  ['paleidimas_0',['Kompiliavimas ir Paleidimas',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['palyginimas_1',['100 000 Įrašų Laikų Palyginimas',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md34',1,'']]],
  ['palyginimas_3a_2',['palyginimas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md26',1,'3 strategija su listais &lt;tt&gt;struct&lt;/tt&gt; ir &lt;tt&gt;class&lt;/tt&gt; palyginimas:'],['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md31',1,'Optimizavimo strategijų (O1, O2, O3) laiko palyginimas:']]],
  ['parašytas_20strong_20ir_20operatorius_20strong_20_3a_3',['Parašytas &lt;strong&gt;&quot;&gt;&gt;&quot; ir &quot;&lt;&lt;&quot; operatorius&lt;/strong&gt;:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md39',1,'']]],
  ['parametrai_4',['Testavimo sistemos parametrai',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md13',1,'']]],
  ['po_3a_5',['Po:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md41',1,'']]],
  ['prieš_3a_6',['Prieš:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md40',1,'']]]
];
