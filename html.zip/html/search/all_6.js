var searchData=
[
  ['analizė_3a_0',['Spartos analizė:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md25',1,'']]],
  ['aprašymas_3a_1',['Aprašymas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md37',1,'']]],
  ['aprašymas_3a_2',['Detalus aprašymas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md38',1,'']]]
];
