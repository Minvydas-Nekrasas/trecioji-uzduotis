var searchData=
[
  ['3_0',['v0.3',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['3_20strategija_20su_20listais_20tt_20struct_20tt_20ir_20tt_20class_20tt_20palyginimas_3a_1',['3 strategija su listais &lt;tt&gt;struct&lt;/tt&gt; ir &lt;tt&gt;class&lt;/tt&gt; palyginimas:',['../md__c_1_2_users_2minvy_2_one_drive_2_desktop_2antroji__uzduotis_2_r_e_a_d_m_e.html#autotoc_md26',1,'']]]
];
